package com.hlw.pojo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "project")
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "project_id") // 映射到表中的 project_id
    private int project_id; // 项目ID

    @Column(name = "manager_id")
    private int manager_id; // 经理ID

    @Column(name = "project_name", nullable = false)
    private String project_name; // 项目名称

    @Column(name = "planned_start_date")
    private LocalDate planned_start_date; // 计划开始日期

    @Column(name = "planned_end_date")
    private LocalDate planned_end_date; // 计划结束日期

    @Column(name = "site_id")
    private int site_id; // 施工场地ID

    @Column(name = "contractor_id")
    private int contractor_id; // 承包商ID

    @Column(name = "budget")
    private double budget; // 预算

    @Column(name = "status")
    private String status; // 项目状态

    @Column(name = "description", columnDefinition = "TEXT")
    private String description; // 项目描述

    @Enumerated(EnumType.STRING)
    @Column(name = "project_type", nullable = false)
    private ProjectType project_type; // 项目类型

    // 定义项目类型枚举
    public enum ProjectType {
        房屋建筑, // 房屋建筑类型
        市政工程  // 市政工程类型
    }
}
