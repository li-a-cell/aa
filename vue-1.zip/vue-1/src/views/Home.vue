<template>
  <div class="main-content">
    <!-- 各类项目自有资金对比 -->
    <div class="chart-container">
      <h3 class="chart-title">各类项目自有资金对比</h3>
      <canvas ref="financeChartRef" class="chart"></canvas>
    </div>

    <!-- 项目状态图表和消息通知栏 -->
    <div class="status-and-notification">
      <!-- 项目状态图表 -->
      <div class="chart-block">
        <h3 class="chart-title">项目状态</h3>
        <canvas ref="statusChartRef" class="chart"></canvas>
      </div>

      <!-- 消息通知栏 -->
      <div v-if="showNotification" class="notification-bar">
        <div class="notification-content">
          <div class="message" v-for="(msg, index) in messages.slice(0, 5)" :key="index">
            <span>{{ msg }}</span>
          </div>
        </div>
        <button @click="closeNotification" class="close-button">&times;</button>
      </div>
    </div>

    <!-- 项目进展 -->
    <div class="progress-block">
      <h3 class="progress-title">项目进展情况</h3>
      <div class="progress-bar">
        <div class="progress-bar-filled" :style="{ width: progress + '%' }"></div>
      </div>
      <p class="progress-text">{{ progress }}% 完成</p>
    </div>

    <!-- 日历 -->
    <div class="calendar-container">
      <div class="calendar-header">
        <button @click="prevMonth" class="calendar-nav">&laquo;</button>
        <h3 class="calendar-title">{{ currentMonth }}</h3>
        <button @click="nextMonth" class="calendar-nav">&raquo;</button>
      </div>

      <!-- Days of the Week -->
      <div class="days-of-week">
        <div class="day-header" v-for="day in daysOfWeek" :key="day">{{ day }}</div>
      </div>

      <!-- Calendar Days -->
      <div class="days">
        <div
          class="day"
          v-for="date in calendarDays"
          :key="date.toISOString()"
          @click="selectDate(date)"
          :class="{
            'highlight': isHighlighted(date),
            'today': isToday(date),
            'disabled': date.getMonth() !== currentDate.getMonth()
          }"
        >
          <span>{{ date.getDate() }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed, watch } from 'vue';
import Chart from 'chart.js/auto';

export default {
  name: 'Home',
  setup() {
    const currentDate = ref(new Date());
    const progress = ref(80);
    const markedDates = ref(['2024-06-01', '2024-06-10', '2024-11-15']);
    const showNotification = ref(true);
    const messages = ref([
      '消息一：系统更新',
      '消息二：检查项目进度',
      '消息三：新增项目A',
      '消息四：项目B已完成',
      '消息五：请检查系统日志',
    ]);

    // 图表引用
    const financeChartRef = ref(null);
    const statusChartRef = ref(null);

    const currentMonth = computed(() => {
      return currentDate.value.toLocaleString('default', { month: 'long', year: 'numeric' });
    });

    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const calendarDays = computed(() => {
      const startOfMonth = new Date(
        currentDate.value.getFullYear(),
        currentDate.value.getMonth(),
        1
      );
      const endOfMonth = new Date(
        currentDate.value.getFullYear(),
        currentDate.value.getMonth() + 1,
        0
      );
      const startDay = startOfMonth.getDay();
      const endDay = endOfMonth.getDay();

      const days = [];

      // 填充上个月的日期
      for (let i = 0; i < startDay; i++) {
        const date = new Date(startOfMonth);
        date.setDate(startOfMonth.getDate() - startDay + i);
        days.push(date);
      }

      // 填充本月的日期
      for (let i = 1; i <= endOfMonth.getDate(); i++) {
        days.push(new Date(currentDate.value.getFullYear(), currentDate.value.getMonth(), i));
      }

      // 填充下个月的日期
      for (let i = 1; i <= 6 - endDay; i++) {
        const date = new Date(endOfMonth);
        date.setDate(endOfMonth.getDate() + i);
        days.push(date);
      }

      return days;
    });

    const isHighlighted = (date) => {
      return markedDates.value.includes(date.toISOString().split('T')[0]);
    };

    const isToday = (date) => {
      const today = new Date();
      return (
        date.getDate() === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear()
      );
    };

    const selectDate = (date) => {
      console.log(`Selected date: ${date}`);
    };

    const prevMonth = () => {
      currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() - 1, 1);
    };

    const nextMonth = () => {
      currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() + 1, 1);
    };

    const closeNotification = () => {
      showNotification.value = false;
    };

    const renderFinanceChart = (ctx) => {
      if (!ctx) return;
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['项目A', '项目B', '项目C', '项目D', '项目E'],
          datasets: [
            {
              label: '项目自有资金',
              data: [24900000, 52748000, 2852000, 47245989, 31000000],
              backgroundColor: '#4e73df',
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              ticks: {
                callback: (value) => '¥' + value.toLocaleString(),
              },
            },
          },
        },
      });
    };

    const renderStatusChart = (ctx) => {
      if (!ctx) return;
      new Chart(ctx, {
        type: 'pie',
        data: {
          labels: ['进行中', '已完成', '暂停'],
          datasets: [
            {
              data: [60, 30, 10],
              backgroundColor: ['#28a745', '#007bff', '#ffc107'],
            },
          ],
        },
      });
    };

    onMounted(() => {
      if (financeChartRef.value) {
        renderFinanceChart(financeChartRef.value);
      }
      if (statusChartRef.value) {
        renderStatusChart(statusChartRef.value);
      }
    });

    watch(currentDate, () => {
      console.log('Current date changed:', currentDate.value);
    });

    return {
      currentDate,
      currentMonth,
      daysOfWeek,
      calendarDays,
      prevMonth,
      nextMonth,
      isHighlighted,
      isToday,
      selectDate,
      closeNotification,
      progress,
      showNotification,
      messages,
      financeChartRef,
      statusChartRef,
    };
  },
};
</script>

<style scoped>
.main-content {
  display: grid;
  grid-template-columns: 2fr 1fr;
  grid-template-rows: auto auto auto;
  grid-gap: 20px;
  width: 100vw;
  height: 100vh;
  padding: 20px;
  background-color: #f5f7fa;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.notification-bar {
  background-color: #ffe4e1;
  padding: 10px;
  text-align: center;
  color: #333;
  font-weight: bold;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  position: relative;
}

.notification-content {
  overflow-y: auto;
  max-height: 150px;
}

.message {
  margin-bottom: 10px;
  padding: 10px;
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #ddd;
}

.close-button {
  background: none;
  border: none;
  font-size: 20px;
  color: #333;
  cursor: pointer;
  position: absolute;
  top: 10px;
  right: 10px;
}

.chart-container,
.chart-block,
.progress-block,
.calendar-container {
  padding: 15px;
  background: #ffffff;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.chart {
  max-height: 300px;
  margin: auto;
}

.progress-bar {
  background: #f0f0f0;
  height: 25px;
  border-radius: 12px;
  overflow: hidden;
}

.progress-bar-filled {
  background: linear-gradient(90deg, #28a745, #85e085);
  height: 100%;
  transition: width 0.5s;
}

.calendar-container {
  background-color: #f9f9f9;
  padding: 20px;
  border-radius: 15px;
  text-align: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.days-of-week {
  display: flex;
  justify-content: space-between;
  font-weight: bold;
}

.days {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.day {
  width: 13%;
  padding: 10px;
  text-align: center;
  cursor: pointer;
  border-radius: 8px;
  font-size: 14px;
  transition: background-color 0.3s;
}

.day.highlight {
  background-color: rgba(255, 99, 132, 0.7);
  color: white;
  font-weight: bold;
}

.day.today {
  background-color: #007bff;
  color: white;
  font-weight: bold;
}

.calendar-nav {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #007bff;
  transition: color 0.3s;
}

.calendar-nav:hover {
  color: #0056b3;
}
</style>
